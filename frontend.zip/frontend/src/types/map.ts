export type ImageryLayerId = 'viking-mdim' | 'mola-shade' | 'ctx-mosaic'

export type OperationalLayerId =
  | 'terrain-elevation'
  | 'temperature'
  | 'wind'
  | 'dust-atmosphere'
  | 'hazards'
  | 'astronauts'
  | 'routes'
  | 'collab-markers'

export type MapLayerId = ImageryLayerId | OperationalLayerId

export type LayerAvailability = 'live' | 'coming-soon'

export type MapLayerCategory = 'imagery' | 'environment' | 'operations'

export interface MapLayerDefinition {
  id: MapLayerId
  category: MapLayerCategory
  label: string
  description: string
  availability: LayerAvailability
  defaultVisible: boolean
  credit?: string
  crs?: string
}

export interface GlobeDisplaySettings {
  showGlobe: boolean
  enableLighting: boolean
  showStarfield: boolean
}

export interface MarsLonLat {
  /** Planetocentric geodetic latitude in degrees, −90 to 90. */
  latitudeDeg: number
  /** East-positive longitude in degrees, wrapped to −180 to 180. */
  longitudeDeg: number
}

export interface PointerCoordinates extends MarsLonLat {
  /** Height above the Mars ellipsoid, in meters. Surface picks are ~0. */
  heightMeters: number
}

export interface CameraStatus {
  /** Geocentric range from the Mars ellipsoid surface, in meters. */
  altitudeMeters: number
}

export type ImageryRuntimeStatus = 'loading' | 'ready' | 'error' | 'ellipsoid-only'

export interface ImagerySourceRecord {
  id: ImageryLayerId
  title: string
  providerKind: 'wmts-rest' | 'url-template'
  urlTemplate: string
  format: 'image/jpeg' | 'image/png'
  tileSize: number
  minLevel: number
  maxLevel: number
  tiling: 'geographic-2x1'
  crs: string
  credit: string
  notes: string
}
