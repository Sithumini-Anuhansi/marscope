import { Compass } from 'lucide-react'
import type { CameraStatus, ImageryRuntimeStatus, PointerCoordinates } from '../../types/map'
import { formatAltitudeKm, formatLatitude, formatLongitude } from '../../utils/marsCoordinates'

interface CoordinateDisplayProps {
  pointer: PointerCoordinates | null
  camera: CameraStatus | null
  imageryStatus: ImageryRuntimeStatus
  usingMarsEllipsoid: boolean
}

export function CoordinateDisplay({
  pointer,
  camera,
  imageryStatus,
  usingMarsEllipsoid,
}: CoordinateDisplayProps) {
  return (
    <div className="rounded-xl border border-line bg-void/85 px-3 py-2.5 shadow-lg backdrop-blur-md">
      <p className="mb-1.5 flex items-center gap-1.5 font-mono text-[10px] tracking-[0.22em] text-gold uppercase">
        <Compass className="h-3 w-3" aria-hidden="true" />
        Coordinates
      </p>
      <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 font-mono text-[11px] text-sand">
        <dt className="text-muted">Lat</dt>
        <dd>{pointer ? formatLatitude(pointer.latitudeDeg) : 'Move cursor over Mars'}</dd>
        <dt className="text-muted">Lon</dt>
        <dd>{pointer ? formatLongitude(pointer.longitudeDeg) : '—'}</dd>
        <dt className="text-muted">Alt</dt>
        <dd>{camera ? formatAltitudeKm(camera.altitudeMeters, 0) : '—'}</dd>
      </dl>
      <p className="mt-2 max-w-[16rem] text-[10px] leading-snug text-muted">
        Planetocentric lon/lat in degrees on Cesium Ellipsoid.MARS (EPSG:104905).
        {usingMarsEllipsoid ? ' Mars ellipsoid active.' : ' Ellipsoid mismatch.'} Imagery:{' '}
        {statusLabel(imageryStatus)}
      </p>
    </div>
  )
}

function statusLabel(status: ImageryRuntimeStatus): string {
  if (status === 'ready') return 'NASA Trek tiles'
  if (status === 'loading') return 'loading tiles'
  if (status === 'error') return 'tile request failed — ellipsoid globe'
  return 'ellipsoid only'
}
