import {
  Cartesian2,
  Cartographic,
  Color,
  Ellipsoid,
  GeographicProjection,
  ScreenSpaceEventType,
  defined,
  type Viewer as CesiumViewer,
} from 'cesium'
import 'cesium/Build/Cesium/Widgets/widgets.css'
import { Layers, LoaderCircle } from 'lucide-react'
import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  CameraFlyTo,
  Fog,
  Globe,
  ImageryLayer,
  Moon,
  Scene,
  ScreenSpaceCameraController,
  ScreenSpaceEvent,
  ScreenSpaceEventHandler,
  SkyAtmosphere,
  SkyBox,
  Sun,
  Viewer,
  useCesium,
} from 'resium'
import { createDefaultLayerVisibility, createImageryProvider } from '../../services/marsImageryService'
import type {
  CameraStatus,
  GlobeDisplaySettings,
  ImageryLayerId,
  ImageryRuntimeStatus,
  PointerCoordinates,
} from '../../types/map'
import {
  MARS_ELLIPSOID,
  MARS_EQUATORIAL_RADIUS_METERS,
  cartographicToLonLat,
  installMarsEllipsoid,
  marsHomeDestination,
} from '../../utils/marsCoordinates'
import { CoordinateDisplay } from './CoordinateDisplay'
import { MapControls } from './MapControls'
import { MapLayers } from './MapLayers'
import { MapLegend } from './MapLegend'

installMarsEllipsoid()

const MARS_PROJECTION = new GeographicProjection(MARS_ELLIPSOID)
const MARS_BASE_COLOR = Color.fromCssColorString('#6b2d22') ?? Color.SIENNA
const SPACE_COLOR = Color.fromCssColorString('#070605') ?? Color.BLACK
const HOME_DESTINATION = marsHomeDestination()
const MIN_ZOOM_METERS = 180_000
const MAX_ZOOM_METERS = 48_000_000
const ZOOM_FRACTION = 0.32

const IMAGERY_PROVIDERS = {
  'viking-mdim': createImageryProvider('viking-mdim'),
  'mola-shade': createImageryProvider('mola-shade'),
  'ctx-mosaic': createImageryProvider('ctx-mosaic'),
} as const

const DEFAULT_SETTINGS: GlobeDisplaySettings = {
  showGlobe: true,
  enableLighting: false,
  showStarfield: true,
}

export function MarsGlobe() {
  const [settings, setSettings] = useState<GlobeDisplaySettings>(DEFAULT_SETTINGS)
  const [imageryVisibility, setImageryVisibility] = useState(createDefaultLayerVisibility)
  const [pointer, setPointer] = useState<PointerCoordinates | null>(null)
  const [camera, setCamera] = useState<CameraStatus | null>(null)
  const [imageryStatus, setImageryStatus] = useState<ImageryRuntimeStatus>('loading')
  const [homeNonce, setHomeNonce] = useState(0)
  const [layersOpen, setLayersOpen] = useState(true)
  const viewerHandle = useRef<CesiumViewer | null>(null)

  const anyImageryOn = Object.values(imageryVisibility).some(Boolean)

  useEffect(() => {
    if (!anyImageryOn) {
      setImageryStatus('ellipsoid-only')
    } else if (imageryStatus === 'ellipsoid-only') {
      setImageryStatus('loading')
    }
  }, [anyImageryOn, imageryStatus])

  const onViewerReady = useCallback((viewer: CesiumViewer) => {
    viewerHandle.current = viewer
    if (viewer.scene.moon) viewer.scene.moon.show = false
  }, [])

  const handleZoom = useCallback((direction: 1 | -1) => {
    const viewer = viewerHandle.current
    if (!viewer) return
    const height = viewer.camera.positionCartographic.height
    const amount = Math.max(height * ZOOM_FRACTION, 80_000)
    if (direction > 0) {
      viewer.camera.zoomIn(amount)
    } else {
      viewer.camera.zoomOut(amount)
    }
  }, [])

  const handleResetView = useCallback(() => {
    setHomeNonce((value) => value + 1)
  }, [])

  const handleToggleImagery = useCallback((id: ImageryLayerId, visible: boolean) => {
    setImageryVisibility((current) => ({ ...current, [id]: visible }))
  }, [])

  const usingMarsEllipsoid = Ellipsoid.default === Ellipsoid.MARS

  return (
    <section className="relative flex min-h-[28rem] flex-1 flex-col overflow-hidden rounded-2xl border border-line bg-[#070605]">
      <Viewer
        full
        className="mars-cesium-viewer"
        ellipsoid={MARS_ELLIPSOID}
        mapProjection={MARS_PROJECTION}
        baseLayer={false}
        baseLayerPicker={false}
        geocoder={false}
        homeButton={false}
        sceneModePicker={false}
        navigationHelpButton={false}
        animation={false}
        timeline={false}
        fullscreenButton={false}
        vrButton={false}
        infoBox={false}
        selectionIndicator={false}
        scene3DOnly
        skyAtmosphere={false}
        requestRenderMode={false}
        shouldAnimate={false}
      >
        <Scene backgroundColor={SPACE_COLOR} />
        <SkyAtmosphere show={false} />
        <SkyBox show={settings.showStarfield} />
        <Sun show={settings.enableLighting} />
        <Moon show={false} />
        <Fog enabled={false} />
        <Globe
          show={settings.showGlobe}
          enableLighting={settings.enableLighting}
          showGroundAtmosphere={false}
          showWaterEffect={false}
          baseColor={MARS_BASE_COLOR}
          onTileLoadProgress={(queued) => {
            if (!anyImageryOn) return
            if (queued > 0) {
              setImageryStatus((status) => (status === 'error' ? status : 'loading'))
              return
            }
            setImageryStatus((status) => (status === 'error' ? status : 'ready'))
          }}
        />
        <ScreenSpaceCameraController
          enableRotate
          enableZoom
          enableTranslate
          enableTilt
          enableLook
          inertiaSpin={0.9}
          inertiaZoom={0.8}
          inertiaTranslate={0.8}
          minimumZoomDistance={MIN_ZOOM_METERS}
          maximumZoomDistance={MAX_ZOOM_METERS}
        />
        <ImageryLayer imageryProvider={IMAGERY_PROVIDERS['viking-mdim']} show={imageryVisibility['viking-mdim']} />
        <ImageryLayer imageryProvider={IMAGERY_PROVIDERS['mola-shade']} show={imageryVisibility['mola-shade']} />
        <ImageryLayer imageryProvider={IMAGERY_PROVIDERS['ctx-mosaic']} show={imageryVisibility['ctx-mosaic']} />
        <CameraFlyTo key={homeNonce} destination={HOME_DESTINATION} duration={homeNonce === 0 ? 0 : 1.15} once />
        <ScreenSpaceEventHandler useDefault>
          <ScreenSpaceEvent type={ScreenSpaceEventType.MOUSE_MOVE} action={(event) => {
            const end = 'endPosition' in event ? event.endPosition : event.position
            setPointer(pickMars(viewerHandle.current, end))
          }} />
        </ScreenSpaceEventHandler>
        <ViewerBridge
          onReady={onViewerReady}
          onCameraChange={setCamera}
          onImageryError={() => setImageryStatus('error')}
        />
      </Viewer>

      {imageryStatus === 'loading' ? (
        <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center bg-void/35">
          <p className="flex items-center gap-2 rounded-full border border-line bg-void/85 px-4 py-2 font-mono text-xs text-sand">
            <LoaderCircle className="h-4 w-4 animate-spin text-gold" aria-hidden="true" />
            Loading Mars imagery…
          </p>
        </div>
      ) : null}

      {imageryStatus === 'error' || imageryStatus === 'ellipsoid-only' ? (
        <div className="absolute top-3 left-1/2 z-20 w-[min(26rem,calc(100%-1.5rem))] -translate-x-1/2 rounded-lg border border-gold/35 bg-void/90 px-3 py-2 text-center text-[11px] text-sand shadow-lg backdrop-blur-md">
          {imageryStatus === 'error'
            ? 'NASA Trek imagery failed to load. Showing a labeled temporary Mars ellipsoid globe — not a scientific mosaic.'
            : 'Surface imagery is turned off. The visible body is the Cesium Mars ellipsoid only.'}
        </div>
      ) : null}

      <div className="pointer-events-none absolute inset-0 z-20 flex flex-col justify-between p-3 md:p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="pointer-events-auto hidden max-w-sm rounded-xl border border-line bg-void/80 px-3 py-2 text-[11px] text-muted backdrop-blur-md sm:block">
            <p className="font-mono text-[10px] tracking-[0.22em] text-gold uppercase">Mars globe</p>
            <p className="mt-1 text-sand">
              Ellipsoid.MARS · radius {(MARS_EQUATORIAL_RADIUS_METERS / 1000).toFixed(0)} km
            </p>
            <p className="mt-0.5">Drag to rotate · scroll to zoom · right-drag to tilt</p>
          </div>
          <div className="pointer-events-auto ml-auto flex flex-col items-end gap-2">
            <MapControls
              settings={settings}
              onZoomIn={() => handleZoom(1)}
              onZoomOut={() => handleZoom(-1)}
              onResetView={handleResetView}
              onSettingsChange={setSettings}
            />
            <button
              type="button"
              className="flex h-9 items-center gap-2 rounded-xl border border-line bg-void/85 px-3 text-[11px] text-sand shadow-lg backdrop-blur-md lg:hidden"
              onClick={() => setLayersOpen((open) => !open)}
              aria-expanded={layersOpen}
            >
              <Layers className="h-3.5 w-3.5 text-gold" />
              Layers
            </button>
          </div>
        </div>

        <div className="flex flex-col items-stretch justify-between gap-3 sm:flex-row sm:items-end">
          <div className="pointer-events-auto">
            <CoordinateDisplay
              pointer={pointer}
              camera={camera}
              imageryStatus={imageryStatus}
              usingMarsEllipsoid={usingMarsEllipsoid}
            />
          </div>
          <div className="pointer-events-auto sm:max-w-[16rem]">
            <MapLegend />
          </div>
        </div>
      </div>

      {layersOpen ? (
        <div className="pointer-events-auto absolute top-3 left-3 z-30 sm:top-auto sm:bottom-auto md:top-3">
          <div className="mt-0 max-lg:mt-12 lg:mt-0">
            <MapLayers imageryVisibility={imageryVisibility} onToggleImagery={handleToggleImagery} />
          </div>
        </div>
      ) : null}
    </section>
  )
}

const ViewerBridge = memo(function ViewerBridge({
  onReady,
  onCameraChange,
  onImageryError,
}: {
  onReady: (viewer: CesiumViewer) => void
  onCameraChange: (status: CameraStatus) => void
  onImageryError: () => void
}) {
  const { viewer } = useCesium()
  const readyRef = useRef(false)

  const providers = useMemo(() => Object.values(IMAGERY_PROVIDERS), [])

  useEffect(() => {
    if (!viewer) return
    if (!readyRef.current) {
      readyRef.current = true
      onReady(viewer)
      onCameraChange({ altitudeMeters: Math.max(0, viewer.camera.positionCartographic.height) })
    }

    const resize = () => viewer.resize()
    const observer = new ResizeObserver(resize)
    observer.observe(viewer.container)

    const removeCamera = viewer.camera.changed.addEventListener(() => {
      onCameraChange({ altitudeMeters: Math.max(0, viewer.camera.positionCartographic.height) })
    })

    const removeErrors = providers.map((provider) =>
      provider.errorEvent.addEventListener(() => {
        onImageryError()
      }),
    )

    window.addEventListener('resize', resize)

    return () => {
      observer.disconnect()
      window.removeEventListener('resize', resize)
      if (typeof removeCamera === 'function') removeCamera()
      removeErrors.forEach((remove) => {
        if (typeof remove === 'function') remove()
      })
    }
  }, [viewer, onReady, onCameraChange, onImageryError, providers])

  return null
})

function pickMars(viewer: CesiumViewer | null, windowPosition: Cartesian2 | undefined): PointerCoordinates | null {
  if (!viewer || !windowPosition) return null
  const cartesian = viewer.camera.pickEllipsoid(windowPosition, MARS_ELLIPSOID)
  if (!defined(cartesian) || !cartesian) return null
  const cartographic = Cartographic.fromCartesian(cartesian, MARS_ELLIPSOID)
  const lonLat = cartographicToLonLat(cartographic)
  return {
    ...lonLat,
    heightMeters: cartographic.height,
  }
}
