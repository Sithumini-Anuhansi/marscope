import { Cartesian3, Cartographic, Ellipsoid, Math as CesiumMath } from 'cesium'
import type { MarsLonLat } from '../types/map'

/**
 * Coordinate handling for MARSCOPE.
 *
 * Runtime globe: Cesium `Ellipsoid.MARS` (mean Mars radius per EPSG:104905).
 * That is a planetary ellipsoid, not WGS84.
 *
 * User-facing values are planetocentric geodetic latitude and east-positive
 * longitude in degrees. Cesium `Cartographic` on this ellipsoid uses the same
 * convention internally (radians).
 *
 * NASA Mars Trek WMTS layers in this app declare EPSG:104905
 * (Mars 2000 geographic / equirectangular, lon/lat in degrees). Do not apply
 * Earth Web Mercator (EPSG:3857) or WGS84 geoid math to those tiles.
 *
 * Planetographic latitude on an oblate Mars ellipsoid differs slightly from
 * planetocentric latitude. Cesium.MARS is currently a sphere of mean radius,
 * so the two coincide for camera/pick math in this viewer.
 */

export const MARS_ELLIPSOID = Ellipsoid.MARS

export const MARS_EQUATORIAL_RADIUS_METERS = MARS_ELLIPSOID.maximumRadius

export const MARS_POLAR_RADIUS_METERS = MARS_ELLIPSOID.minimumRadius

/** Default camera height for a whole-planet view, meters above the ellipsoid. */
export const MARS_HOME_HEIGHT_METERS = 14_000_000

export const MARS_HOME_LON_LAT: MarsLonLat = {
  latitudeDeg: 10,
  longitudeDeg: 0,
}

export function installMarsEllipsoid(): Ellipsoid {
  Ellipsoid.default = Ellipsoid.MARS
  return Ellipsoid.MARS
}

export function degreesToRadians(degrees: number): number {
  return CesiumMath.toRadians(degrees)
}

export function radiansToDegrees(radians: number): number {
  return CesiumMath.toDegrees(radians)
}

export function wrapLongitudeDegrees(longitudeDeg: number): number {
  const wrapped = ((((longitudeDeg + 180) % 360) + 360) % 360) - 180
  return wrapped === -180 ? 180 : wrapped
}

export function clampLatitudeDegrees(latitudeDeg: number): number {
  return Math.min(90, Math.max(-90, latitudeDeg))
}

export function lonLatToCartesian(
  longitudeDeg: number,
  latitudeDeg: number,
  heightMeters = 0,
  ellipsoid: Ellipsoid = MARS_ELLIPSOID,
): Cartesian3 {
  return Cartesian3.fromDegrees(
    wrapLongitudeDegrees(longitudeDeg),
    clampLatitudeDegrees(latitudeDeg),
    heightMeters,
    ellipsoid,
  )
}

export function cartographicToLonLat(cartographic: Cartographic): MarsLonLat {
  return {
    latitudeDeg: clampLatitudeDegrees(radiansToDegrees(cartographic.latitude)),
    longitudeDeg: wrapLongitudeDegrees(radiansToDegrees(cartographic.longitude)),
  }
}

export function formatLatitude(latitudeDeg: number, digits = 3): string {
  const hemisphere = latitudeDeg >= 0 ? 'N' : 'S'
  return `${Math.abs(latitudeDeg).toFixed(digits)}° ${hemisphere}`
}

export function formatLongitude(longitudeDeg: number, digits = 3): string {
  const wrapped = wrapLongitudeDegrees(longitudeDeg)
  const hemisphere = wrapped >= 0 ? 'E' : 'W'
  return `${Math.abs(wrapped).toFixed(digits)}° ${hemisphere}`
}

export function formatLonLat(position: MarsLonLat, digits = 3): string {
  return `${formatLatitude(position.latitudeDeg, digits)}, ${formatLongitude(position.longitudeDeg, digits)}`
}

export function formatAltitudeKm(meters: number, digits = 0): string {
  if (!Number.isFinite(meters)) return '—'
  if (Math.abs(meters) >= 1000) {
    return `${(meters / 1000).toFixed(digits)} km`
  }
  return `${meters.toFixed(0)} m`
}

export function marsHomeDestination(): Cartesian3 {
  return lonLatToCartesian(
    MARS_HOME_LON_LAT.longitudeDeg,
    MARS_HOME_LON_LAT.latitudeDeg,
    MARS_HOME_HEIGHT_METERS,
  )
}
